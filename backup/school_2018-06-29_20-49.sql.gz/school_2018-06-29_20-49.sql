#SKD101|school|1|2018.06.29 20:49:22|1|1

DROP TABLE IF EXISTS `courses`;
CREATE TABLE `courses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` text NOT NULL,
  `tuts` int(11) unsigned DEFAULT NULL,
  `homeworks` int(11) unsigned DEFAULT NULL,
  `level` varchar(191) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `courses` VALUES
(2, 'Курс по верстке', 10, 8, 'Для новичков');

